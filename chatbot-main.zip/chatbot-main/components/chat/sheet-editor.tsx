"use client";

import { useTheme } from "next-themes";
import { parse, unparse } from "papaparse";
import { memo, useCallback, useEffect, useMemo, useState } from "react";
import DataGrid, { textEditor } from "react-data-grid";
import { cn } from "@/lib/utils";

import "react-data-grid/lib/styles.css";

type SheetEditorProps = {
  content: string;
  saveContent: (content: string, isCurrentVersion: boolean) => void;
  currentVersionIndex: number;
  isCurrentVersion: boolean;
  status: string;
};

const MIN_ROWS = 50;
const MIN_COLS = 26;

const PureSpreadsheetEditor = ({ content, saveContent }: SheetEditorProps) => {
  const { resolvedTheme } = useTheme();

  const parseData = useMemo(() => {
    if (!content) {
      return new Array(MIN_ROWS).fill(new Array(MIN_COLS).fill(""));
    }
    const result = parse<string[]>(content, { skipEmptyLines: true });

    const paddedData = result.data.map((row) => {
      const paddedRow = [...row];
      while (paddedRow.length < MIN_COLS) {
        paddedRow.push("");
      }
      return paddedRow;
    });

    while (paddedData.length < MIN_ROWS) {
      paddedData.push(new Array(MIN_COLS).fill(""));
    }

    return paddedData;
  }, [content]);

  const columns = useMemo(() => {
    const rowNumberColumn = {
      cellClass: "border-t border-r dark:bg-neutral-950 dark:text-neutral-50",
      frozen: true,
      headerCellClass:
        "border-t border-r dark:bg-neutral-900 dark:text-neutral-50",
      key: "rowNumber",
      name: "",
      renderCell: ({ rowIdx }: { rowIdx: number }) => rowIdx + 1,
      width: 50,
    };

    const dataColumns = Array.from({ length: MIN_COLS }, (_, i) => ({
      cellClass: cn("border-t dark:bg-neutral-950 dark:text-neutral-50", {
        "border-l": i !== 0,
      }),
      headerCellClass: cn("border-t dark:bg-neutral-900 dark:text-neutral-50", {
        "border-l": i !== 0,
      }),
      key: i.toString(),
      name: String.fromCharCode(65 + i),
      renderEditCell: textEditor,
      width: 120,
    }));

    return [rowNumberColumn, ...dataColumns];
  }, []);

  const initialRows = useMemo(
    () =>
      parseData.map((row, rowIndex) => {
        const rowData: Record<string, string | number> = {
          id: rowIndex,
          rowNumber: rowIndex + 1,
        };

        columns.slice(1).forEach((col, colIndex) => {
          rowData[col.key] = row[colIndex] || "";
        });

        return rowData;
      }),
    [parseData, columns]
  );

  const [localRows, setLocalRows] = useState(initialRows);

  useEffect(() => {
    setLocalRows(initialRows);
  }, [initialRows]);

  const generateCsv = (data: string[][]) => unparse(data);

  const handleRowsChange = (newRows: Record<string, string | number>[]) => {
    setLocalRows(newRows);

    const updatedData = newRows.map((row) =>
      columns.slice(1).map((col) => String(row[col.key] ?? ""))
    );

    const newCsvContent = generateCsv(updatedData);
    saveContent(newCsvContent, true);
  };

  const handleCellClick = useCallback(
    (args: {
      column: { key: string };
      selectCell: (enableEditor?: boolean) => void;
    }) => {
      if (args.column.key !== "rowNumber") {
        args.selectCell(true);
      }
    },
    []
  );

  return (
    <DataGrid
      className={resolvedTheme === "dark" ? "rdg-dark" : "rdg-light"}
      columns={columns}
      defaultColumnOptions={{
        resizable: true,
        sortable: true,
      }}
      enableVirtualization
      onCellClick={handleCellClick}
      onRowsChange={handleRowsChange}
      rows={localRows}
      style={{ height: "100%" }}
    />
  );
};

function areEqual(prevProps: SheetEditorProps, nextProps: SheetEditorProps) {
  return (
    prevProps.currentVersionIndex === nextProps.currentVersionIndex &&
    prevProps.isCurrentVersion === nextProps.isCurrentVersion &&
    !(prevProps.status === "streaming" && nextProps.status === "streaming") &&
    prevProps.content === nextProps.content &&
    prevProps.saveContent === nextProps.saveContent
  );
}

export const SpreadsheetEditor = memo(PureSpreadsheetEditor, areEqual);
